## Mongoose/MongoDB Queries
## CoreJS concepts
## String Method
## Array Method
## Pagination
## add to cart  [DONE]
## Lock user for 1 hour after 3 unsuccessfull login attempts with wrong password []
## user can post reviews and rate the product