const Product = require("../../models/Product");
// const deleteFile = require("../../helper/deletefile");
// const path = require("path");

//Update category
const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, price, qty, image, categoryId } = req.body;
    // const postData = await Product.findById({ _id: id });
    // const filePath = postData.image;
    const updateProduct = await Product.findByIdAndUpdate(
      id,
      {
        $set: {
          name: name,
          description: description,
          price: price,
          qty: qty,
          //image: req.file.filename,
          categoryId: categoryId,
        },
      },
      { new: true }
    );
    if (!updateProduct) {
      res.status(404).send({ status: "failed", message: "Product Not Found" });
    }
    // const fullPath = "/Users/c100-99/Desktop/Learning/Ecom_platform/public/productimage";
    // const filePath1 = path.join(fullPath, filePath);
    // deleteFile(filePath1);
    await updateProduct.save();
    res
      .status(200)
      .send({ status: "success", message: "Product Updated Successfully" });
  } catch (error) {
    res.json(error);
  }
};

module.exports = updateProduct;
