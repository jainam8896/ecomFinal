const User = require("../../models/User");
const bcrypt = require("bcrypt");
const CustomError = require("../../utils/errors/CustomError");

const changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id).select("password");

    if (!bcrypt.compareSync(currentPassword, user.password)) {
      return next(new CustomError("Invalid Current Password", 404));
    }
    
    const hasPassword = bcrypt.hashSync(newPassword, 10);
    user.password = hasPassword;
    await user.save();
    return res.status(200).send({
      status: "success",
      message: "Password Changed Successfully",
    });
  } catch (error) {
    console.error(error);
    return next(new CustomError("Internal Server Error", 500));
  }
};

module.exports = changePassword;
