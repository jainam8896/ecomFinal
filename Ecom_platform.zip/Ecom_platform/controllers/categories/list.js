const Category = require("../../models/Category");
const pagination = require("../../helper/pagination");

const listCategory = async (req, res) => {
  try {
    const params = req.body;
    const category = await pagination(params, Category);
    res.json(category);
  } catch (error) {
    console.log("error: ", error);
    res.status(500).json(error);
  }
};

module.exports = listCategory;
