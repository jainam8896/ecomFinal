const Rating = require("../../models/Rating");
const CustomError = require("../../utils/errors/CustomError");

const addRating = async (req, res) => {
  const { productId } = req.params;
  const { ratings } = req.body;
  const rating = new Rating({
    ratings: ratings,
    userId: req.user._id,
    productId: productId,
  });
  const newRating = await rating.save();
  return res.status(201).send(newRating);
};

module.exports = addRating;
