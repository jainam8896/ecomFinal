const express = require("express");
const router = express.Router();
const addReview = require("../controllers/reviews/add");
const deleteReview = require("../controllers/reviews/delete");
const listReview = require("../controllers/reviews/list");
const updateReview = require("../controllers/reviews/update")

//Add Review
router.post("/:productId", addReview);

//Delete Review
router.delete("/:id",deleteReview);

//List Review
router.get("/",listReview)

//Update Reviews
router.patch("/:productId/reviews/:id", updateReview)

module.exports = router;
